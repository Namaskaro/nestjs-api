import 'dotenv/config';

import { randomUUID } from 'node:crypto';

import { HumanMessage } from '@langchain/core/messages';
import { NestFactory } from '@nestjs/core';

import { AppModule } from '@/src/core/app.module';

import { SupportAgentGraph } from '../graph/support-agent.graph';

import type { SupportAgentStateType } from '../graph/support-agent.state';

function getNode(metadata: unknown): string | null {
  if (!metadata || typeof metadata !== 'object') {
    return null;
  }

  const node = (metadata as Record<string, unknown>).langgraph_node;

  return typeof node === 'string' ? node : null;
}

function getRunName(serialized: unknown, fallback: string): string {
  if (!serialized || typeof serialized !== 'object') {
    return fallback;
  }

  const runnable = serialized as {
    name?: unknown;
    id?: unknown;
  };

  if (typeof runnable.name === 'string') {
    return runnable.name;
  }

  if (Array.isArray(runnable.id)) {
    const name = runnable.id.at(-1);

    if (typeof name === 'string') {
      return name;
    }
  }

  return fallback;
}

function printSeparator(title: string): void {
  console.log('\n');
  console.log('='.repeat(100));
  console.log(title);
  console.log('='.repeat(100));
}

async function bootstrap(): Promise<void> {
  const app = await NestFactory.createApplicationContext(AppModule, {
    logger: ['error', 'warn'],
  });

  try {
    const supportAgentGraph = app.get(SupportAgentGraph);

    const graph = supportAgentGraph.getCompiledGraph();

    const query = 'Найди кроссовки kobe';

    const threadId = `live-product-debug-${randomUUID()}`;

    printSeparator('USER QUERY');

    console.log(query);

    const callbacks = [
      {
        handleChainEnd: async (
          outputs: unknown,
          _runId: string,
          _parentRunId?: string,
          _tags?: string[],
          _kwargs?: unknown,
          metadata?: unknown,
        ) => {
          const node = getNode(metadata);

          if (node !== 'requestRouterNode') {
            return;
          }

          printSeparator('REQUEST ROUTER OUTPUT');

          console.dir(outputs, {
            depth: null,
            colors: true,
          });
        },

        handleToolStart: async (
          serialized: unknown,
          input: unknown,
          _runId: string,
          _parentRunId?: string,
          _tags?: string[],
          metadata?: unknown,
          runName?: string,
        ) => {
          const name = runName ?? getRunName(serialized, 'unknown-tool');

          if (name !== 'search_products') {
            return;
          }

          printSeparator('SEARCH_PRODUCTS TOOL INPUT');

          console.log(`node: ${getNode(metadata) ?? '-'}`);

          console.dir(input, {
            depth: null,
            colors: true,
          });
        },

        handleToolEnd: async (
          output: unknown,
          _runId: string,
          _parentRunId?: string,
          _tags?: string[],
          metadata?: unknown,
        ) => {
          if (getNode(metadata) !== 'productAgent') {
            return;
          }

          printSeparator('SEARCH_PRODUCTS TOOL OUTPUT');

          console.dir(output, {
            depth: null,
            colors: true,
          });
        },
      },
    ];

    const result = (await graph.invoke(
      {
        query,

        messages: [new HumanMessage(query)],
      },
      {
        configurable: {
          thread_id: threadId,
        },

        callbacks,
      },
    )) as SupportAgentStateType;

    printSeparator('FINAL RESULT');

    console.dir(
      {
        requestRouter: result.requestRouter,

        activeAgent: result.activeAgent,

        answer: result.answer,
      },
      {
        depth: null,
        colors: true,
      },
    );
  } finally {
    await app.close();
  }
}

bootstrap().catch((error: unknown) => {
  console.error('\nLIVE PRODUCT SEARCH DEBUG FAILED');

  console.error(error);

  process.exitCode = 1;
});
