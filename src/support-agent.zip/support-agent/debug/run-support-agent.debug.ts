import 'dotenv/config';

import { randomUUID } from 'node:crypto';

import { HumanMessage } from '@langchain/core/messages';
import { NestFactory } from '@nestjs/core';

import { AppModule } from '@/src/core/app.module';

import { applyProductPlan } from '../agents/product-agent/product-plan';
import { ProductPlannerResultSchema } from '../agents/product-agent/schemas/product-planner-result.schema';
import {
  readProductContext,
  type ProductContext,
  type ProductNeedMemory,
} from '../schemas/product-context.schema';
import { SupportAgentGraph } from '../graph/support-agent.graph';
import type { SupportAgentStateType } from '../graph/support-agent.state';

const RUN_PAID_SMOKE = process.env.RUN_PRODUCT_CONTEXT_LLM_SMOKE === '1';

function normalize(value: unknown): string {
  return String(value ?? '')
    .trim()
    .toLowerCase()
    .replaceAll('ё', 'е');
}

function assert(condition: unknown, message: string): asserts condition {
  if (!condition) {
    throw new Error(message);
  }
}

function assertEqual(actual: unknown, expected: unknown, label: string): void {
  if (actual !== expected) {
    throw new Error(
      `${label}: expected=${JSON.stringify(expected)}, actual=${JSON.stringify(
        actual,
      )}`,
    );
  }
}

function assertTextEqual(
  actual: unknown,
  expected: unknown,
  label: string,
): void {
  if (normalize(actual) !== normalize(expected)) {
    throw new Error(
      `${label}: expected=${JSON.stringify(expected)}, actual=${JSON.stringify(
        actual,
      )}`,
    );
  }
}

function assertThrows(run: () => unknown, expectedText: string): void {
  try {
    run();
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);

    if (!message.includes(expectedText)) {
      throw new Error(
        `Ожидалась ошибка с текстом ${JSON.stringify(
          expectedText,
        )}, получено ${JSON.stringify(message)}`,
      );
    }

    return;
  }

  throw new Error(`Ожидалась ошибка: ${expectedText}`);
}

function findNeed(
  context: ProductContext,
  predicate: (need: ProductNeedMemory) => boolean,
  label: string,
): ProductNeedMemory {
  const need = context.needs.find(predicate);

  assert(need, `Не найдена потребность: ${label}`);

  return need;
}

function createInitialContext(): ProductContext {
  const plan = ProductPlannerResultSchema.parse({
    updates: [
      {
        needId: null,
        semanticQuery: 'женские кроссовки',
        filterChanges: [
          { field: 'gender', value: 'WOMAN' },
          { field: 'type', value: 'SHOES' },
          { field: 'brand', value: 'Nike' },
          { field: 'size', value: '42' },
        ],
        addPreferences: [],
        removePreferences: [],
      },
      {
        needId: null,
        semanticQuery: 'костюм на свадьбу',
        filterChanges: [{ field: 'type', value: 'CLOTHES' }],
        addPreferences: ['для свадьбы'],
        removePreferences: [],
      },
    ],
    removeNeedIds: [],
    reuseNeedIds: [],
    comparison: null,
    clarification: null,
  });

  return applyProductPlan(null, plan).productContext;
}

function runDeterministicProductContextDebug(): void {
  console.log('PRODUCT CONTEXT V2 DETERMINISTIC DEBUG');
  console.log('Paid LLM calls: 0');
  console.log('');

  let context = createInitialContext();

  assertEqual(context.version, 2, 'context.version');
  assertEqual(context.needs.length, 2, 'initial needs.length');

  const initialShoes = findNeed(
    context,
    (need) => need.filters.type === 'SHOES',
    'кроссовки',
  );

  const initialSuit = findNeed(
    context,
    (need) => normalize(need.semanticQuery).includes('костюм'),
    'костюм',
  );

  const shoesNeedId = initialShoes.needId;
  const suitNeedId = initialSuit.needId;

  console.log('✅ Созданы две независимые потребности');

  const colorPatch = ProductPlannerResultSchema.parse({
    updates: [
      {
        needId: shoesNeedId,
        semanticQuery: null,
        filterChanges: [{ field: 'color', value: 'чёрный' }],
        addPreferences: [],
        removePreferences: [],
      },
    ],
    removeNeedIds: [],
    reuseNeedIds: [],
    comparison: null,
    clarification: null,
  });

  const colorResult = applyProductPlan(context, colorPatch);
  context = colorResult.productContext;

  const patchedShoes = findNeed(
    context,
    (need) => need.needId === shoesNeedId,
    'кроссовки после patch',
  );

  const preservedSuit = findNeed(
    context,
    (need) => need.needId === suitNeedId,
    'костюм после patch обуви',
  );

  assertTextEqual(patchedShoes.filters.color, 'чёрный', 'shoes.color');
  assertTextEqual(patchedShoes.filters.brand, 'Nike', 'shoes.brand');
  assertTextEqual(patchedShoes.filters.size, '42', 'shoes.size');
  assertEqual(patchedShoes.filters.gender, 'WOMAN', 'shoes.gender');
  assertEqual(preservedSuit.needId, suitNeedId, 'suit.needId');
  assertEqual(context.needs.length, 2, 'needs after shoes patch');
  assertEqual(colorResult.searchNeedIds.length, 1, 'searchNeedIds.length');
  assertEqual(colorResult.searchNeedIds[0], shoesNeedId, 'searchNeedIds[0]');

  console.log('✅ Patch цвета изменил только обувь');
  console.log('✅ Nike, размер 42 и костюм сохранились');
  console.log('✅ Новый поиск назначен только изменённой потребности');

  const addNeedPlan = ProductPlannerResultSchema.parse({
    updates: [
      {
        needId: null,
        semanticQuery: 'рубашка',
        filterChanges: [{ field: 'type', value: 'CLOTHES' }],
        addPreferences: [],
        removePreferences: [],
      },
    ],
    removeNeedIds: [],
    reuseNeedIds: [],
    comparison: null,
    clarification: null,
  });

  const addNeedResult = applyProductPlan(context, addNeedPlan);
  context = addNeedResult.productContext;

  assertEqual(context.needs.length, 3, 'needs after new need');

  assert(
    context.needs.some((need) => need.needId === shoesNeedId),
    'Кроссовки потерялись после добавления новой потребности',
  );

  assert(
    context.needs.some((need) => need.needId === suitNeedId),
    'Костюм потерялся после добавления новой потребности',
  );

  console.log('✅ Новая потребность не удаляет старые');

  const removeSuitPlan = ProductPlannerResultSchema.parse({
    updates: [],
    removeNeedIds: [suitNeedId],
    reuseNeedIds: [],
    comparison: null,
    clarification: null,
  });

  const removeSuitResult = applyProductPlan(context, removeSuitPlan);
  context = removeSuitResult.productContext;

  assertEqual(context.needs.length, 2, 'needs after remove suit');

  assert(
    !context.needs.some((need) => need.needId === suitNeedId),
    'Удалённый костюм остался в памяти',
  );

  assert(
    context.needs.some((need) => need.needId === shoesNeedId),
    'Удаление костюма затронуло обувь',
  );

  console.log('✅ removeNeedIds удаляет только адресную потребность');

  const contextWithShownProducts = readProductContext(structuredClone(context));

  const shoesWithProducts = findNeed(
    contextWithShownProducts,
    (need) => need.needId === shoesNeedId,
    'кроссовки для reuse',
  );

  shoesWithProducts.shownProducts = [
    {
      id: 'product-1',
      title: 'Nike Test 1',
      price: '10000',
      image: 'https://example.com/product-1.webp',
    },
    {
      id: 'product-2',
      title: 'Nike Test 2',
      price: '12000',
      image: 'https://example.com/product-2.webp',
    },
  ];

  contextWithShownProducts.displayOrder = [
    { needId: shoesNeedId, productId: 'product-1' },
    { needId: shoesNeedId, productId: 'product-2' },
  ];

  const reusePlan = ProductPlannerResultSchema.parse({
    updates: [],
    removeNeedIds: [],
    reuseNeedIds: [shoesNeedId],
    comparison: null,
    clarification: null,
  });

  const reuseResult = applyProductPlan(contextWithShownProducts, reusePlan);

  assertEqual(reuseResult.searchNeedIds.length, 0, 'reuse searchNeedIds');
  assertEqual(reuseResult.activeNeedIds.length, 1, 'reuse activeNeedIds');
  assertEqual(reuseResult.activeNeedIds[0], shoesNeedId, 'reuse needId');

  const reusedShoes = findNeed(
    reuseResult.productContext,
    (need) => need.needId === shoesNeedId,
    'кроссовки после reuse',
  );

  assertEqual(reusedShoes.shownProducts.length, 2, 'shownProducts after reuse');

  console.log('✅ reuse использует сохранённые карточки без нового поиска');

  const comparisonPlan = ProductPlannerResultSchema.parse({
    updates: [],
    removeNeedIds: [],
    reuseNeedIds: [],
    comparison: [
      { needId: shoesNeedId, productId: 'product-1' },
      { needId: shoesNeedId, productId: 'product-2' },
    ],
    clarification: null,
  });

  const comparisonResult = applyProductPlan(
    contextWithShownProducts,
    comparisonPlan,
  );

  assertEqual(
    comparisonResult.productContext.comparison.length,
    2,
    'comparison.length',
  );

  assertEqual(comparisonResult.searchNeedIds.length, 0, 'comparison search');

  console.log('✅ comparison ссылается на реальные shownProducts');

  const clarificationPlan = ProductPlannerResultSchema.parse({
    updates: [],
    removeNeedIds: [],
    reuseNeedIds: [],
    comparison: null,
    clarification: {
      needId: shoesNeedId,
      question: 'Какой размер нужен?',
      fields: ['size'],
    },
  });

  const clarificationResult = applyProductPlan(
    contextWithShownProducts,
    clarificationPlan,
  );

  assertEqual(
    clarificationResult.productContext.pendingClarification?.needId,
    shoesNeedId,
    'pendingClarification.needId',
  );

  assertEqual(
    clarificationResult.productContext.pendingClarification?.fields[0],
    'size',
    'pendingClarification.fields[0]',
  );

  assertTextEqual(
    clarificationResult.productContext.pendingClarification?.question,
    'Какой размер нужен?',
    'pendingClarification.question',
  );

  console.log(
    '✅ pendingClarification адресно связывает следующий короткий ответ',
  );

  const unknownNeedPlan = ProductPlannerResultSchema.parse({
    updates: [
      {
        needId: 'unknown-need-id',
        semanticQuery: null,
        filterChanges: [{ field: 'color', value: 'белый' }],
        addPreferences: [],
        removePreferences: [],
      },
    ],
    removeNeedIds: [],
    reuseNeedIds: [],
    comparison: null,
    clarification: null,
  });

  assertThrows(
    () => applyProductPlan(context, unknownNeedPlan),
    'неизвестный needId',
  );

  console.log('✅ Неизвестный needId отклоняется сервером');
  console.log('');
  console.log('✅ PRODUCT CONTEXT V2 DETERMINISTIC DEBUG PASSED');
}

function findShoesNeed(context: ProductContext): ProductNeedMemory {
  return findNeed(
    context,
    (need) =>
      need.filters.type === 'SHOES' ||
      normalize(need.semanticQuery).includes('кроссов'),
    'кроссовки',
  );
}

function findSuitNeed(context: ProductContext): ProductNeedMemory {
  return findNeed(
    context,
    (need) => normalize(need.semanticQuery).includes('костюм'),
    'костюм',
  );
}

async function invokeTurn(
  graph: ReturnType<SupportAgentGraph['getCompiledGraph']>,
  threadId: string,
  query: string,
): Promise<SupportAgentStateType> {
  console.log('');
  console.log(`USER: ${query}`);

  const result = (await graph.invoke(
    {
      query,
      messages: [new HumanMessage(query)],
    },
    {
      configurable: {
        thread_id: threadId,
      },
    },
  )) as SupportAgentStateType;

  console.log('ASSISTANT:');

  console.dir(result.answer, {
    depth: 8,
    colors: true,
  });

  console.log('PRODUCT CONTEXT:');

  console.dir(result.productContext, {
    depth: 8,
    colors: true,
  });

  return result;
}

async function runPaidConversationSmoke(): Promise<void> {
  console.log('');
  console.log('PRODUCT CONTEXT V2 REAL LLM SMOKE');
  console.log('Paid mode: ENABLED');

  const app = await NestFactory.createApplicationContext(AppModule, {
    logger: ['error', 'warn'],
  });

  try {
    const supportAgentGraph = app.get(SupportAgentGraph);
    const graph = supportAgentGraph.getCompiledGraph();
    const threadId = `product-context-v2-debug-${randomUUID()}`;

    const first = await invokeTurn(
      graph,
      threadId,
      'Нужны женские кроссовки Nike 42 размера и костюм на свадьбу',
    );

    const firstContext = readProductContext(first.productContext);
    const firstShoes = findShoesNeed(firstContext);
    const firstSuit = findSuitNeed(firstContext);

    assertEqual(firstContext.needs.length, 2, 'turn1 needs.length');
    assertTextEqual(firstShoes.filters.brand, 'Nike', 'turn1 shoes.brand');
    assertTextEqual(firstShoes.filters.size, '42', 'turn1 shoes.size');

    const shoesNeedId = firstShoes.needId;
    const suitNeedId = firstSuit.needId;

    const second = await invokeTurn(graph, threadId, 'А обувь чёрную?');

    const secondContext = readProductContext(second.productContext);

    const secondShoes = findNeed(
      secondContext,
      (need) => need.needId === shoesNeedId,
      'те же кроссовки после смены цвета',
    );

    const secondSuit = findNeed(
      secondContext,
      (need) => need.needId === suitNeedId,
      'тот же костюм после смены цвета обуви',
    );

    assertEqual(secondContext.needs.length, 2, 'turn2 needs.length');
    assertTextEqual(secondShoes.filters.color, 'чёрный', 'turn2 shoes.color');
    assertTextEqual(secondShoes.filters.brand, 'Nike', 'turn2 shoes.brand');
    assertTextEqual(secondShoes.filters.size, '42', 'turn2 shoes.size');
    assertEqual(secondSuit.needId, suitNeedId, 'turn2 suit.needId');

    console.log('✅ Turn 2: обувь обновлена адресно, костюм сохранён');

    const third = await invokeTurn(
      graph,
      threadId,
      'Какие у вас условия доставки?',
    );

    const thirdContext = readProductContext(third.productContext);

    assert(
      thirdContext.needs.some((need) => need.needId === shoesNeedId),
      'После CustomerHelp потерялись кроссовки',
    );

    assert(
      thirdContext.needs.some((need) => need.needId === suitNeedId),
      'После CustomerHelp потерялся костюм',
    );

    console.log('✅ Turn 3: CustomerHelp не уничтожил ProductContext');

    const fourth = await invokeTurn(
      graph,
      threadId,
      'Вернёмся к костюму: чёрный, до 20000 рублей',
    );

    const fourthContext = readProductContext(fourth.productContext);

    const fourthSuit = findNeed(
      fourthContext,
      (need) => need.needId === suitNeedId,
      'костюм после возврата к консультации',
    );

    assertTextEqual(fourthSuit.filters.color, 'чёрный', 'turn4 suit.color');
    assertEqual(fourthSuit.filters.maxPrice, 20000, 'turn4 suit.maxPrice');

    assert(
      fourthContext.needs.some((need) => need.needId === shoesNeedId),
      'После возврата к костюму потерялись кроссовки',
    );

    console.log('✅ Turn 4: старая потребность продолжена по тому же needId');
    console.log('');
    console.log('✅ PRODUCT CONTEXT V2 REAL LLM SMOKE PASSED');
  } finally {
    await app.close();
  }
}

async function bootstrap(): Promise<void> {
  runDeterministicProductContextDebug();

  if (!RUN_PAID_SMOKE) {
    console.log('');

    console.log(
      'ℹ️ Real LLM smoke пропущен. Для запуска установи RUN_PRODUCT_CONTEXT_LLM_SMOKE=1.',
    );

    return;
  }

  await runPaidConversationSmoke();
}

bootstrap().catch((error: unknown) => {
  console.error('');
  console.error('❌ PRODUCT CONTEXT V2 DEBUG FAILED');
  console.error(error instanceof Error ? error.message : error);

  process.exitCode = 1;
});
