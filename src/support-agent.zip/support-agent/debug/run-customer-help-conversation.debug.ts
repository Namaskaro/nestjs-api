import 'dotenv/config';

import { randomUUID } from 'node:crypto';

import { HumanMessage } from '@langchain/core/messages';
import { NestFactory } from '@nestjs/core';

import { AppModule } from '@/src/core/app.module';

import { SupportAgentGraph } from '../graph/support-agent.graph';

async function bootstrap(): Promise<void> {
  const app = await NestFactory.createApplicationContext(AppModule, {
    logger: ['error', 'warn'],
  });

  try {
    const supportAgentGraph = app.get(SupportAgentGraph);

    const graph = supportAgentGraph.getCompiledGraph();

    const threadId = `customer-help-context-debug-${randomUUID()}`;

    console.log('\n');
    console.log('='.repeat(90));
    console.log('CUSTOMER HELP CONTEXT DEBUG');
    console.log(`THREAD ID: ${threadId}`);
    console.log('='.repeat(90));

    async function runTurn(turn: number, query: string): Promise<void> {
      console.log(`\n--- TURN ${turn} ---`);
      console.log(`USER: ${query}`);
      console.log('');

      const stream = await graph.stream(
        {
          query,

          messages: [new HumanMessage(query)],
        },
        {
          configurable: {
            thread_id: threadId,
          },

          streamMode: 'updates',

          subgraphs: true,
        },
      );

      for await (const update of stream) {
        console.dir(update, {
          depth: null,
          colors: true,
        });
      }
    }

    await runTurn(1, 'Какие условия возврата товара?');

    // ВАЖНО:
    // Именно фраза из UI.
    //
    // Здесь намеренно НЕ добавляем
    // "на возврат", потому что хотим проверить,
    // умеет ли parent graph использовать историю.
    await runTurn(2, 'А сколько у меня дней?');

    console.log('\n');
    console.log('='.repeat(90));
  } finally {
    await app.close();
  }
}

bootstrap().catch((error: unknown) => {
  console.error('Не удалось запустить Customer Help context debug:');

  console.error(error);

  process.exitCode = 1;
});
