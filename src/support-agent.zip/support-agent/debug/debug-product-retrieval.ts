import 'dotenv/config';

import { NestFactory } from '@nestjs/core';

import { AppModule } from '@/src/core/app.module';

import { AiService } from '@/src/ai/ai.service';
import { ProductQdrantPayloadSchema } from '@/src/ai/schemas/product-qdrant-payload.schema';

import { PrismaService } from '@/src/core/prisma/prisma.service';

import { QdrantCollections } from '@/src/core/qdrant/qdrant.collections';

import {
  QDRANT_CLIENT,
  QDRANT_DENSE_VECTOR,
  QDRANT_SPARSE_VECTOR,
} from '@/src/core/qdrant/qdrant.constants';

import {
  QdrantService,
  type QdrantFilter,
  type QdrantSearchPoint,
} from '@/src/core/qdrant/qdrant.service';

import { RerankerService } from '@/src/core/reranker/reranker.service';

import { ProductAgentService } from '../agents/product-agent/product-agent.service';

import type { ProductNeed } from '../agents/product-agent/schemas/product-need.schema';

const LIMIT = 20;

function printSeparator(title: string): void {
  console.log('\n');
  console.log('='.repeat(100));
  console.log(title);
  console.log('='.repeat(100));
}

function getPointTitle(point: QdrantSearchPoint): string {
  const parsed = ProductQdrantPayloadSchema.safeParse(point.payload);

  if (!parsed.success) {
    return 'INVALID PAYLOAD';
  }

  return parsed.data.title;
}

function printPoints(label: string, points: QdrantSearchPoint[]): void {
  console.log(`\n${label}`);

  if (points.length === 0) {
    console.log('NO RESULTS');

    return;
  }

  console.table(
    points.map((point, index) => {
      const parsed = ProductQdrantPayloadSchema.safeParse(point.payload);

      if (!parsed.success) {
        return {
          rank: index + 1,
          score: point.score,
          title: 'INVALID PAYLOAD',
          type: '-',
          brand: '-',
          subcategory: '-',
        };
      }

      const payload = parsed.data;

      return {
        rank: index + 1,
        score: point.score,
        title: payload.title,
        type: payload.type,
        brand: payload.brand,
        subcategory: payload.subcategory,
      };
    }),
  );
}

async function bootstrap(): Promise<void> {
  const app = await NestFactory.createApplicationContext(AppModule, {
    logger: ['error', 'warn'],
  });

  try {
    const prismaService = app.get(PrismaService);

    const aiService = app.get(AiService);

    const qdrantService = app.get(QdrantService);

    const rerankerService = app.get(RerankerService);

    const productAgentService = app.get(ProductAgentService);

    const qdrantClient = app.get(QDRANT_CLIENT, {
      strict: false,
    });

    printSeparator('1. KOBE PRODUCT В POSTGRES');

    const kobeProduct = await prismaService.product.findFirst({
      where: {
        title: {
          contains: 'Kobe',
          mode: 'insensitive',
        },
      },

      include: {
        brand: true,

        subcategory: {
          include: {
            category: true,
          },
        },
      },
    });

    if (!kobeProduct) {
      throw new Error('В Postgres не найден товар с Kobe в title');
    }

    console.dir(
      {
        id: kobeProduct.id,
        title: kobeProduct.title,

        brand: kobeProduct.brand?.name ?? null,

        category: kobeProduct.subcategory?.category?.name ?? null,

        subcategory: kobeProduct.subcategory?.name ?? null,

        subcategoryId: kobeProduct.subcategoryId,

        type: kobeProduct.type,

        gender: kobeProduct.gender,

        color: kobeProduct.color,

        sizes: kobeProduct.sizes,

        inStock: kobeProduct.inStock,
      },
      {
        depth: null,
        colors: true,
      },
    );

    printSeparator('2. ВСЕ SUBCATEGORY ИЗ POSTGRES');

    const subcategories = await prismaService.subcategory.findMany({
      select: {
        id: true,
        name: true,
      },

      orderBy: {
        name: 'asc',
      },
    });

    console.table(subcategories);

    printSeparator('3. KOBE POINT НАПРЯМУЮ ИЗ QDRANT');

    const storedPoints = await qdrantClient.retrieve(
      QdrantCollections.products,
      {
        ids: [kobeProduct.id],

        with_payload: true,

        with_vector: false,
      },
    );

    if (storedPoints.length === 0) {
      console.log('KOBE POINT В QDRANT НЕ НАЙДЕН');
    } else {
      const point = storedPoints[0];

      const parsed = ProductQdrantPayloadSchema.safeParse(point.payload);

      if (!parsed.success) {
        console.log('KOBE POINT ЕСТЬ, НО PAYLOAD НЕ ПРОШЁЛ SCHEMA');

        console.dir(parsed.error, {
          depth: null,
          colors: true,
        });
      } else {
        console.dir(
          {
            id: point.id,

            title: parsed.data.title,

            brand: parsed.data.brand,

            type: parsed.data.type,

            subcategory: parsed.data.subcategory,

            subcategoryId: parsed.data.subcategoryId,

            color: parsed.data.color,

            colorKey: parsed.data.colorKey,

            details: parsed.data.details,

            searchText: parsed.data.searchText,
          },
          {
            depth: null,
            colors: true,
          },
        );
      }
    }

    const hardFilter = {
      must: [
        {
          key: 'inStock',

          match: {
            value: true,
          },
        },

        {
          key: 'type',

          match: {
            value: kobeProduct.type,
          },
        },

        ...(kobeProduct.subcategoryId
          ? [
              {
                key: 'subcategoryId',

                match: {
                  value: kobeProduct.subcategoryId,
                },
              },
            ]
          : []),
      ],
    } satisfies QdrantFilter;

    const queries = ['Kobe', 'кроссовки Kobe', 'баскетбольные кроссовки'];

    for (const query of queries) {
      printSeparator(`QUERY: ${query}`);

      const queryEmbedding = await aiService.createQueryEmbedding(query);

      const denseResult = await qdrantClient.query(QdrantCollections.products, {
        query: queryEmbedding,

        using: QDRANT_DENSE_VECTOR,

        filter: hardFilter,

        limit: LIMIT,

        with_payload: true,
      });

      printPoints('DENSE RESULTS', denseResult.points);

      const bm25Result = await qdrantClient.query(QdrantCollections.products, {
        query: {
          text: query,

          model: 'qdrant/bm25',
        },

        using: QDRANT_SPARSE_VECTOR,

        filter: hardFilter,

        limit: LIMIT,

        with_payload: true,
      });

      printPoints('BM25 RESULTS', bm25Result.points);

      const hybridResult = await qdrantService.hybridSearch(
        QdrantCollections.products,

        queryEmbedding,

        query,

        LIMIT,

        hardFilter,
      );

      printPoints('HYBRID RRF RESULTS', hybridResult);

      const reranked = await rerankerService.rerank(
        query,

        hybridResult,

        (candidate) => {
          const payload = ProductQdrantPayloadSchema.parse(candidate.payload);

          return payload.searchText;
        },

        5,
      );

      console.log('\nRERANKER RESULTS');

      if (reranked.length === 0) {
        console.log('NO RESULTS');
      } else {
        console.table(
          reranked.map(({ item }, index) => ({
            rank: index + 1,

            title: getPointTitle(item),
          })),
        );
      }
    }

    printSeparator('4. PRODUCT AGENT SERVICE — MANUAL PRODUCT NEED');

    const manualProductNeed: ProductNeed = {
      semanticQuery: 'кроссовки Kobe',

      filters: {
        gender: null,

        type: 'SHOES',

        brand: null,

        category: null,

        subcategory: 'кроссовки',

        color: null,

        size: null,

        minPrice: null,

        maxPrice: null,
      },
    };

    console.dir(manualProductNeed, {
      depth: null,
      colors: true,
    });

    const serviceResult = await productAgentService.searchProducts(
      manualProductNeed,
    );

    console.log('\nPRODUCT AGENT SERVICE RESULT');

    console.dir(serviceResult, {
      depth: null,
      colors: true,
    });
  } finally {
    await app.close();
  }
}

bootstrap().catch((error: unknown) => {
  console.error('\nPRODUCT RETRIEVAL DEBUG FAILED');

  console.error(error);

  process.exitCode = 1;
});
