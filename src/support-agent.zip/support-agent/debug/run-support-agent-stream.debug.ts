import { randomUUID } from 'node:crypto';

import { NestFactory } from '@nestjs/core';

import { AppModule } from '@/src/core/app.module';

import { SupportAgentService } from '../support-agent.service';

type DebugEvent = {
  seq: number;
  method: string;
  node: string | undefined;
  dataEvent: string | undefined;
};

async function runSupportAgentStreamDebug(): Promise<void> {
  const app = await NestFactory.createApplicationContext(AppModule);

  try {
    const supportAgentService = app.get(SupportAgentService);

    const query = 'Подбери чёрные мужские кроссовки до 15 000 рублей';

    const threadId = `stream-debug-${randomUUID()}`;

    console.log(
      '\n============================================================',
    );
    console.log('STREAM DEBUG');
    console.log('QUERY:', query);
    console.log('THREAD ID:', threadId);
    console.log(
      '============================================================\n',
    );

    const stream = await supportAgentService.streamEvents(query, threadId);

    const lastEvents: DebugEvent[] = [];

    try {
      for await (const event of stream) {
        console.log(
          `\n[${event.seq}] method=${event.method} node=${
            event.params.node ?? '-'
          }`,
        );

        if (event.method === 'custom') {
          console.log('CUSTOM DATA:');

          console.dir(event.params.data, {
            depth: null,
          });
        }

        if (event.method === 'tasks') {
          console.log('TASK DATA:');

          console.dir(event.params.data, {
            depth: null,
          });
        }

        if (event.method === 'updates') {
          console.log('UPDATE DATA:');

          console.dir(event.params.data, {
            depth: 3,
          });
        }
      }
    } catch (error) {
      console.log(
        '\n============================================================',
      );
      console.log('LAST EVENTS BEFORE ERROR');
      console.log(
        '============================================================\n',
      );

      console.dir(lastEvents, {
        depth: null,
      });

      throw error;
    }

    const output = await stream.output;

    console.log(
      '\n============================================================',
    );
    console.log('FINAL OUTPUT');
    console.log(
      '============================================================\n',
    );

    console.dir(
      {
        answer: output.answer,
        interrupted: stream.interrupted,
        interrupts: stream.interrupts,
      },
      {
        depth: null,
      },
    );
  } finally {
    await app.close();
  }
}

void runSupportAgentStreamDebug();
