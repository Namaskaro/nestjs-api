import 'dotenv/config';

import { NestFactory } from '@nestjs/core';

import { AiService } from '@/src/ai/ai.service';
import { ProductSemanticInputDto } from '@/src/ai/dto/product-semantic-input.dto';
import { ProductQdrantPayload } from '@/src/ai/schemas/product-qdrant-payload.schema';
import { AppModule } from '@/src/core/app.module';
import { PrismaService } from '@/src/core/prisma/prisma.service';
import { QdrantCollections } from '@/src/core/qdrant/qdrant.collections';
import { QdrantService } from '@/src/core/qdrant/qdrant.service';

// START CHANGES — НОРМАЛИЗАЦИЯ COLOR ДЛЯ HARD FILTER

import { normalizeSearchFilterValue } from '@/src/shared/utils/normalize-search-filter-value';

// END CHANGES — НОРМАЛИЗАЦИЯ COLOR ДЛЯ HARD FILTER

async function bootstrap(): Promise<void> {
  const app = await NestFactory.createApplicationContext(AppModule, {
    logger: ['error', 'warn'],
  });

  const prismaService = app.get(PrismaService);
  const aiService = app.get(AiService);
  const qdrantService = app.get(QdrantService);

  try {
    const products = await prismaService.product.findMany({
      include: {
        brand: true,
        subcategory: {
          include: {
            category: true,
          },
        },
      },
      orderBy: {
        createdAt: 'asc',
      },
    });

    console.log(`\nНайдено товаров для reindex: ${products.length}\n`);

    let indexed = 0;
    let skipped = 0;

    const failed: Array<{
      id: string;
      title: string;
      error: string;
    }> = [];

    for (const [index, product] of products.entries()) {
      const position = `[${index + 1}/${products.length}]`;

      if (!product.brand || !product.subcategory) {
        skipped += 1;

        console.warn(
          `${position} SKIP: ${product.title} (${product.id}) — нет brand или subcategory`,
        );

        continue;
      }

      try {
        console.log(
          `${position} INDEX: ${product.title} | color=${
            product.color ?? 'null'
          }`,
        );

        const semanticInput: ProductSemanticInputDto = {
          title: product.title,
          description: product.description,
          brand: product.brand.name,
          subcategory: product.subcategory.name,
          color: product.color ?? '',

          // START CHANGES — DETAILS ИЗ POSTGRES В SEMANTIC INPUT

          details: product.details,

          // END CHANGES — DETAILS ИЗ POSTGRES В SEMANTIC INPUT

          price: product.price,
        };

        const semanticRepresentation =
          await aiService.createProductSemanticRepresentation(semanticInput);

        const searchText = aiService.buildProductSearchText(
          semanticInput,
          semanticRepresentation,
        );

        const denseEmbedding = await aiService.createProductEmbedding(
          searchText,
        );

        await prismaService.$executeRaw`
          INSERT INTO "ProductEmbedding" ("productId", "vector")
          VALUES (
            ${product.id},
            ${JSON.stringify(denseEmbedding)}::vector
          )
          ON CONFLICT ("productId")
          DO UPDATE SET "vector" = EXCLUDED."vector"
        `;

        const payload: ProductQdrantPayload = {
          productId: product.id,

          title: product.title,
          description: product.description,

          brandId: product.brand.id,
          brand: product.brand.name,

          categoryId: product.subcategory.category.id,
          category: product.subcategory.category.name,

          subcategoryId: product.subcategory.id,
          subcategory: product.subcategory.name,

          color: product.color,

          // START CHANGES — COLOR KEY + DETAILS В QDRANT PAYLOAD

          colorKey: product.color
            ? normalizeSearchFilterValue(product.color)
            : null,

          details: product.details,

          // END CHANGES — COLOR KEY + DETAILS В QDRANT PAYLOAD

          price: Number(product.price),

          gender: product.gender,
          type: product.type,

          sizes: product.sizes,
          stock: product.stock,

          image: product.images[0] ?? '',
          inStock: product.inStock,

          searchText,

          semanticRepresentation,
        };

        await qdrantService.savePoint(QdrantCollections.products, {
          id: product.id,

          vector: {
            dense: denseEmbedding,

            bm25: {
              text: searchText,
              model: 'qdrant/bm25',
            },
          },

          payload,
        });

        indexed += 1;

        console.log(`${position} OK\n`);
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);

        failed.push({
          id: product.id,
          title: product.title,
          error: message,
        });

        console.error(`${position} FAILED: ${product.title}`);
        console.error(message);
        console.error('');
      }
    }

    console.log('\n' + '='.repeat(80));
    console.log('PRODUCT REINDEX FINISHED');
    console.log(`Indexed: ${indexed}`);
    console.log(`Skipped: ${skipped}`);
    console.log(`Failed: ${failed.length}`);
    console.log('='.repeat(80));

    if (failed.length > 0) {
      console.dir(failed, {
        depth: null,
        colors: true,
      });

      process.exitCode = 1;
    }
  } finally {
    await app.close();
  }
}

bootstrap().catch((error: unknown) => {
  console.error('\nPRODUCT REINDEX DEBUG FAILED');
  console.error(error);

  process.exitCode = 1;
});
