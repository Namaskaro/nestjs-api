import 'dotenv/config';

import { randomUUID } from 'node:crypto';

import { HumanMessage } from '@langchain/core/messages';
import { NestFactory } from '@nestjs/core';

import { AppModule } from '@/src/core/app.module';

import { SupportAgentGraph } from '../graph/support-agent.graph';

async function bootstrap(): Promise<void> {
  const app = await NestFactory.createApplicationContext(AppModule, {
    logger: ['error', 'warn'],
  });

  try {
    const supportAgentGraph = app.get(SupportAgentGraph);

    const graph = supportAgentGraph.getCompiledGraph();

    const query = 'Какие условия возврата товара?';

    const threadId = `customer-help-debug-${randomUUID()}`;

    console.log('\n');
    console.log('='.repeat(90));
    console.log('CUSTOMER HELP DEBUG');
    console.log(`QUERY: ${query}`);
    console.log(`THREAD ID: ${threadId}`);
    console.log('='.repeat(90));

    const stream = await graph.stream(
      {
        query,

        messages: [new HumanMessage(query)],
      },
      {
        configurable: {
          thread_id: threadId,
        },

        streamMode: 'updates',

        subgraphs: true,
      },
    );

    for await (const update of stream) {
      console.dir(update, {
        depth: null,
        colors: true,
      });
    }
  } finally {
    await app.close();
  }
}

bootstrap().catch((error: unknown) => {
  console.error('Не удалось запустить Customer Help debug:');

  console.error(error);

  process.exitCode = 1;
});
