import { tool } from '@langchain/core/tools';
import { Command } from '@langchain/langgraph';
import { z } from 'zod';

export const AGENT_NODE_NAMES = ['customerHelp', 'productSearch'] as const;

export const AgentNodeSchema = z.enum(AGENT_NODE_NAMES);

export type AgentNodeName = z.infer<typeof AgentNodeSchema>;

type AgentHandoffConfig = Partial<Record<AgentNodeName, string>>;

export const AGENT_HANDOFFS = {
  productSearch: {
    customerHelp:
      'Используй customerHelp, если пользователь спрашивает о доставке, оплате, возврате, обмене, скидках, программе лояльности или других правилах магазина.',
  },

  customerHelp: {
    productSearch:
      'Используй productSearch, если пользователь хочет найти, подобрать, сравнить или получить рекомендацию по товарам.',
  },
} satisfies Record<AgentNodeName, AgentHandoffConfig>;

export function getAgentHandoffDestinations(
  sourceAgent: AgentNodeName,
): AgentNodeName[] {
  const handoffs = AGENT_HANDOFFS[sourceAgent] as AgentHandoffConfig;

  return Object.keys(handoffs) as AgentNodeName[];
}

export const AGENT_ROUTE_MAP = Object.fromEntries(
  AGENT_NODE_NAMES.map((agentName) => [agentName, agentName]),
) as Record<AgentNodeName, AgentNodeName>;

export function createAgentHandoffTool(sourceAgent: AgentNodeName) {
  const handoffs = AGENT_HANDOFFS[sourceAgent] as AgentHandoffConfig;

  const targets = getAgentHandoffDestinations(sourceAgent);

  if (targets.length === 0) {
    throw new Error(
      `CreateAgentHandoffTool: для ${sourceAgent} не настроены handoff targets`,
    );
  }

  const targetAgentSchema = z.enum(
    targets as [AgentNodeName, ...AgentNodeName[]],
  );

  const targetsDescription = targets
    .map((targetAgent) => {
      return `${targetAgent}: ${handoffs[targetAgent]}`;
    })
    .join('\n');

  return tool(
    async ({ targetAgent }) => {
      return new Command({
        goto: targetAgent,
        graph: Command.PARENT,
        update: {
          activeAgent: targetAgent,
        },
      });
    },
    {
      name: 'transfer_to_agent',
      description: [
        'Передай управление другому специализированному агенту,',
        'если текущий запрос пользователя больше не относится',
        'к твоей области ответственности.',
        '',
        'Доступные агенты:',
        targetsDescription,
      ].join('\n'),

      schema: z.object({
        targetAgent: targetAgentSchema.describe(
          'Агент, которому нужно передать дальнейшее ведение разговора.',
        ),
      }),
    },
  );
}
