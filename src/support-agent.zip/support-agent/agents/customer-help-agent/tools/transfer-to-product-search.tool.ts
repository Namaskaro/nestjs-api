import { tool } from '@langchain/core/tools';
import { Command } from '@langchain/langgraph';
import { z } from 'zod';

export const transferToProductSearchTool = tool(
  async () => {
    return new Command({
      goto: 'productSearch',

      graph: Command.PARENT,

      update: {
        // ProductAgent становится владельцем диалога.
        activeAgent: 'productSearch',
      },
    });
  },
  {
    name: 'transfer_to_product_search',

    description:
      'Передай управление в поиск товаров, если пользователь хочет найти, подобрать, сравнить или получить рекомендацию по товарам.',

    schema: z.object({}),
  },
);
