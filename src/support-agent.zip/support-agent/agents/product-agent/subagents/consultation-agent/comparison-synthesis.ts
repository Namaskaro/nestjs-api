import { HumanMessage, SystemMessage } from '@langchain/core/messages';

import { AiService } from '../../../../../ai/ai.service';

import {
  ComparisonSynthesisInputSchema,
  ComparisonSynthesisOutputSchema,
  type ComparisonSynthesisInput,
  type ComparisonSynthesisOutput,
} from '../../schemas/comparison-presentation.schema';

import { comparisonSynthesisPrompt } from './prompts/comparison-synthesis.prompt';

// ===== START CHANGE: NON-CRITICAL SYNTHESIS DEADLINE =====

const COMPARISON_SYNTHESIS_TIMEOUT_MS = 12_000;

// ===== END CHANGE: NON-CRITICAL SYNTHESIS DEADLINE =====

export function createComparisonSynthesis(aiService: AiService) {
  const model = aiService
    .getYandexLiteChatModel()
    .withStructuredOutput(ComparisonSynthesisOutputSchema, {
      name: 'summarize_product_comparison',

      includeRaw: true,
    });

  return {
    async summarizeComparison(
      rawInput: ComparisonSynthesisInput,
    ): Promise<ComparisonSynthesisOutput | null> {
      const input = ComparisonSynthesisInputSchema.parse(rawInput);

      try {
        const response = await model.invoke(
          [
            new SystemMessage(comparisonSynthesisPrompt),

            new HumanMessage(JSON.stringify(input)),
          ],

          // ===== START CHANGE: SYNTHESIS CANNOT HOLD THE WHOLE TURN =====

          {
            signal: AbortSignal.timeout(COMPARISON_SYNTHESIS_TIMEOUT_MS),
          },

          // ===== END CHANGE: SYNTHESIS CANNOT HOLD THE WHOLE TURN =====
        );

        const parsed = ComparisonSynthesisOutputSchema.safeParse(
          response.parsed,
        );

        if (!parsed.success) {
          return null;
        }

        if (
          parsed.data.preferredPosition !== null &&
          !input.products.some(
            (product) => product.position === parsed.data.preferredPosition,
          )
        ) {
          return null;
        }

        return parsed.data;
      } catch {
        return null;
      }
    },
  };
}

export type ComparisonSynthesis = ReturnType<typeof createComparisonSynthesis>;
