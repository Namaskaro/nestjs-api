import { tool } from 'langchain';

import {
  ConsultationAgentResultSchema,
  ConsultationCompletionSchema,
  type ConsultationAgentResult,
  type ConsultationCompletion,
} from '../schemas/consultation-agent.schema';

export function createCompleteConsultationStepTool(
  complete: (result: ConsultationCompletion) => ConsultationAgentResult,
) {
  return tool(
    async (result) => {
      const verified = ConsultationAgentResultSchema.parse(complete(result));

      return [verified.message, verified];
    },
    {
      name: 'complete_consultation_step',
      description:
        'Завершает консультацию после серверной проверки памяти, сравнений и рекомендаций.',
      schema: ConsultationCompletionSchema,
      responseFormat: 'content_and_artifact',
      returnDirect: true,
    },
  );
}
