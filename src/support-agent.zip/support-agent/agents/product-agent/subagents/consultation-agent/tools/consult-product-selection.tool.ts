import { HumanMessage, ToolMessage } from '@langchain/core/messages';

import { Command } from '@langchain/langgraph';

import { tool, type ToolRuntime } from 'langchain';

import { ProductAgentState } from '../../../product-agent.state';

import { ConsultationAgent } from '../consultation.agent';

import {
  ConsultationAgentInputSchema,
  ConsultationAgentResultSchema,
} from '../schemas/consultation-agent.schema';

export function createConsultProductSelectionTool(
  consultationAgent: ConsultationAgent,
) {
  return tool(
    async (input, runtime: ToolRuntime<typeof ProductAgentState.State>) => {
      // START CHANGES — CONSULTATION AGENT RETURNS TERMINAL TOOL MESSAGE

      const result = await consultationAgent.invoke({
        messages: [
          new HumanMessage(
            /*
             * Без pretty-print.
             * Это LLM context, поэтому лишние пробелы нам не нужны.
             */
            JSON.stringify({
              searches: input.searches,
            }),
          ),
        ],
      });

      const finalMessage = result.messages.at(-1);

      if (!ToolMessage.isInstance(finalMessage)) {
        throw new Error(
          'ConsultProductSelectionTool: ConsultationAgent не завершился через complete_consultation_step',
        );
      }

      /*
       * complete_consultation_step использует:
       *
       * responseFormat: 'content_and_artifact'
       *
       * поэтому:
       *
       * finalMessage.content
       * → короткий message
       *
       * finalMessage.artifact
       * → полный ConsultationAgentResult
       */
      const consultation = ConsultationAgentResultSchema.parse(
        finalMessage.artifact,
      );

      // END CHANGES — CONSULTATION AGENT RETURNS TERMINAL TOOL MESSAGE

      return new Command({
        update: {
          consultation,

          messages: [
            new ToolMessage({
              /*
               * В ProductAgent LLM возвращаем только готовый
               * пользовательский текст.
               *
               * decisions и alternativePlan уже лежат
               * в typed ProductAgentState.consultation.
               */
              content: consultation.message,

              tool_call_id: runtime.toolCall?.id ?? '',
            }),
          ],
        },
      });
    },
    {
      name: 'consult_product_selection',

      description: [
        'Анализирует завершённые поиски товаров.',
        'Вызывай один раз после всех search_products текущего цикла.',
        'Передай ProductNeed и найденные title/price каждого поиска.',
        'Возвращает следующий шаг консультации и готовый короткий message пользователю.',
      ].join(' '),

      schema: ConsultationAgentInputSchema,
    },
  );
}
