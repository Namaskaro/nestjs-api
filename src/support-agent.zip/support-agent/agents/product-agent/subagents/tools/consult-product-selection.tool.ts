// START CHANGES — CONSULTATION AGENT AS A TOOL

import { HumanMessage } from '@langchain/core/messages';

import { tool } from 'langchain';
import { ConsultationAgent } from '../consultation-agent/consultation.agent';
import {
  ConsultationAgentInputSchema,
  ConsultationAgentResultSchema,
} from '../consultation-agent/schemas/consultation-agent.schema';

export function createConsultProductSelectionTool(
  consultationAgent: ConsultationAgent,
) {
  return tool(
    async (input) => {
      const result = await consultationAgent.invoke({
        messages: [
          new HumanMessage(
            JSON.stringify(
              {
                searches: input.searches,
              },
              null,
              2,
            ),
          ),
        ],
      });

      const advice = ConsultationAgentResultSchema.parse(
        result.structuredResponse,
      );

      return [advice.message, advice];
    },
    {
      name: 'consult_product_selection',

      description: [
        'Внутренний товарный консультант.',
        'Используй после завершения одного или нескольких search_products перед финальным ответом пользователю.',
        'Передай завершённые поиски: ProductNeed и найденные title/price.',
        'Консультант определит, какие параметры действительно полезно предложить уточнить дальше.',
        'Вызывай один раз после всех поисков текущего turn.',
        'Не вызывай до search_products и не повторяй без новых результатов.',
      ].join(' '),

      schema: ConsultationAgentInputSchema,

      responseFormat: 'content_and_artifact',
    },
  );
}
