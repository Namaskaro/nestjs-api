// ===== START CHANGE: DETERMINISTIC COMPARISON PRESENTATION =====

import type { ProductNeedMemory } from '../../../schemas/product-context.schema';

import type {
  CategoryProfile,
  ProductComparison,
  ProductDetails,
  ProductFact,
} from '../consultation-core/consultation-core.schema';

import {
  ComparisonPresentationSchema,
  type ComparisonPresentation,
  type ComparisonSynthesisInput,
  type ComparisonSynthesisOutput,
} from '../schemas/comparison-presentation.schema';

const HIDDEN_COMPARISON_ATTRIBUTES = new Set([
  'inStock',
  'stock',
  'type',
  'category',
  'subcategory',
  'gender',
]);

const MAX_KEY_DIFFERENCES = 4;

export type PreparedComparisonPresentation = {
  comparisonId: string;

  needId: string;

  goal: string;

  products: ComparisonPresentation['products'];

  rows: ComparisonPresentation['rows'];

  synthesisInput: ComparisonSynthesisInput;

  unavailableRequestedLabels: string[];
};

function clip(value: string, maxLength: number): string {
  if (value.length <= maxLength) {
    return value;
  }

  return value.slice(0, Math.max(0, maxLength - 1)) + '…';
}

function formatFact(
  fact: Pick<ProductFact, 'status' | 'value' | 'unit' | 'displayValue'>,
): string {
  if (fact.status !== 'known') {
    return 'не указано';
  }

  if (fact.displayValue) {
    return fact.displayValue;
  }

  if (Array.isArray(fact.value)) {
    return fact.value.join(', ');
  }

  if (typeof fact.value === 'boolean') {
    return fact.value ? 'да' : 'нет';
  }

  if (fact.value === null) {
    return 'не указано';
  }

  return fact.unit ? `${String(fact.value)} ${fact.unit}` : String(fact.value);
}

function comparisonGoal(need: ProductNeedMemory): string {
  const storedGoals = need.consultation.goals
    .map((goal) => goal.text)
    .filter(Boolean);

  return clip(
    [need.semanticQuery, ...storedGoals]
      .filter((value, index, values) => values.indexOf(value) === index)
      .join('. '),

    1000,
  );
}

function orderedProducts(
  comparison: ProductComparison,
  products: ProductDetails[],
): ProductDetails[] {
  const byId = new Map(
    products.map((product) => [product.id, product] as const),
  );

  return comparison.productIds.map((productId) => {
    const product = byId.get(productId);

    if (!product) {
      throw new Error(
        `ProductAgent: product details отсутствуют для ${productId}`,
      );
    }

    return product;
  });
}

function buildSynthesisRows(comparison: ProductComparison) {
  const positionByProductId = new Map(
    comparison.productIds.map(
      (productId, index) => [productId, index + 1] as const,
    ),
  );

  return comparison.rows
    .filter((row) => !HIDDEN_COMPARISON_ATTRIBUTES.has(row.attributeId))
    .map((row) => ({
      attributeId: row.attributeId,

      label: row.label,

      cells: row.cells.map((cell) => ({
        position: positionByProductId.get(cell.productId) ?? 0,

        status: cell.fact.status,

        value: cell.fact.value,

        unit: cell.fact.unit,

        displayValue: cell.fact.displayValue,
      })),
    }));
}

function buildPresentationRows(
  comparison: ProductComparison,
  requestedAttributeIds: readonly string[],
): ComparisonPresentation['rows'] {
  const requested = new Set(requestedAttributeIds);

  return comparison.rows
    .filter((row) => !HIDDEN_COMPARISON_ATTRIBUTES.has(row.attributeId))
    .filter((row) => {
      const explicitlyRequested = requested.has(row.attributeId);

      if (explicitlyRequested) {
        return true;
      }

      const hasKnownFact = row.cells.some(
        (cell) => cell.fact.status === 'known',
      );

      if (!hasKnownFact) {
        return false;
      }

      /*
       * Одинаковая характеристика не является
       * полезным различием для общего сравнения.
       *
       * Если пользователь явно её запросил —
       * она прошла выше.
       */
      return row.state !== 'same';
    })
    .map((row) => ({
      attributeId: row.attributeId,

      label: row.label,

      cells: row.cells.map((cell) => ({
        productId: cell.productId,

        status: cell.fact.status,

        value: cell.fact.value,

        unit: cell.fact.unit,

        displayValue: cell.fact.displayValue,
      })),
    }));
}

function unavailableRequestedLabels(
  comparison: ProductComparison,
  requestedAttributeIds: readonly string[],
): string[] {
  const requested = new Set(requestedAttributeIds);

  return comparison.rows
    .filter(
      (row) =>
        requested.has(row.attributeId) &&
        !HIDDEN_COMPARISON_ATTRIBUTES.has(row.attributeId) &&
        row.cells.every((cell) => cell.fact.status !== 'known'),
    )
    .map((row) => row.label);
}

export function prepareComparisonPresentation({
  comparison,
  products,
  need,
  profile,
  currentQuery,
  requestedAttributeIds,
}: {
  comparison: ProductComparison;

  products: ProductDetails[];

  need: ProductNeedMemory;

  profile: CategoryProfile;

  currentQuery: string;

  requestedAttributeIds: readonly string[];
}): PreparedComparisonPresentation {
  const ordered = orderedProducts(comparison, products);

  const goal = comparisonGoal(need);

  const presentationProducts: ComparisonPresentation['products'] = ordered.map(
    (product, index) => ({
      position: index + 1,

      productId: product.id,

      title: product.title,

      image: product.images.find((image) => image.trim().length > 0) ?? null,

      price: product.price,

      currency: product.currency,

      brand: product.brand?.name ?? null,
    }),
  );

  const rows = buildPresentationRows(comparison, requestedAttributeIds);

  const synthesisRows = buildSynthesisRows(comparison);

  const synthesisAttributeIds = new Set(
    synthesisRows.map((row) => row.attributeId),
  );

  const guidance = profile.guidance
    .filter((rule) =>
      rule.attributeIds.some((attributeId) =>
        synthesisAttributeIds.has(attributeId),
      ),
    )
    .slice(0, 8)
    .map((rule) => ({
      when: rule.when,

      attributeIds: rule.attributeIds,

      instruction: rule.instruction,
    }));

  const synthesisInput: ComparisonSynthesisInput = {
    goal,

    currentQuery: clip(currentQuery, 500),

    preferences: need.preferences.slice(0, 10),

    goals: need.consultation.goals
      .slice(0, 8)
      .map((storedGoal) => storedGoal.text),

    products: presentationProducts.map((product) => ({
      position: product.position,

      title: product.title,

      price: product.price,

      currency: product.currency,

      brand: product.brand,
    })),

    rows: synthesisRows,

    guidance,
  };

  return {
    comparisonId: comparison.comparisonId,

    needId: comparison.needId,

    goal,

    products: presentationProducts,

    rows,

    synthesisInput,

    unavailableRequestedLabels: unavailableRequestedLabels(
      comparison,
      requestedAttributeIds,
    ),
  };
}

function deterministicDifference(
  row: ComparisonPresentation['rows'][number],
  products: ComparisonPresentation['products'],
): string {
  const titleById = new Map(
    products.map((product) => [product.productId, product.title] as const),
  );

  const values = row.cells.map((cell) => {
    const title = titleById.get(cell.productId) ?? 'Товар';

    return `${title} — ${formatFact(cell)}`;
  });

  return clip(
    `${row.label}: ${values.join('; ')}.`,

    400,
  );
}

function deterministicFallback(
  prepared: PreparedComparisonPresentation,
): ComparisonSynthesisOutput {
  const keyDifferences = prepared.rows
    .slice(0, MAX_KEY_DIFFERENCES)
    .map((row) => deterministicDifference(row, prepared.products));

  const labels = prepared.rows
    .map((row) => row.label)
    .slice(0, MAX_KEY_DIFFERENCES);

  const recommendation = labels.length
    ? clip(
        `По проверенным данным варианты различаются прежде всего по: ${labels.join(
          ', ',
        )}. Для задачи «${
          prepared.goal
        }» явного лидера без дополнительной интерпретации нет — ориентируйтесь на эти различия.`,

        1200,
      )
    : clip(
        `По доступным проверенным характеристикам существенных различий между вариантами не обнаружено. Для задачи «${prepared.goal}» явного лидера нет.`,

        1200,
      );

  const note = prepared.unavailableRequestedLabels.length
    ? clip(
        `Недостаточно данных по явно запрошенным характеристикам: ${prepared.unavailableRequestedLabels.join(
          ', ',
        )}.`,

        600,
      )
    : null;

  return {
    keyDifferences,

    recommendation,

    preferredPosition: null,

    note,
  };
}

export function finalizeComparisonPresentation(
  prepared: PreparedComparisonPresentation,

  synthesis: ComparisonSynthesisOutput | null,
): ComparisonPresentation {
  const result = synthesis ?? deterministicFallback(prepared);

  const recommendedProductId =
    result.preferredPosition === null
      ? null
      : prepared.products.find(
          (product) => product.position === result.preferredPosition,
        )?.productId ?? null;

  return ComparisonPresentationSchema.parse({
    comparisonId: prepared.comparisonId,

    needId: prepared.needId,

    goal: prepared.goal,

    products: prepared.products,

    rows: prepared.rows,

    keyDifferences: result.keyDifferences,

    recommendation: result.recommendation,

    recommendedProductId,

    note: result.note,
  });
}

export function buildComparisonMessage(
  presentation: ComparisonPresentation,
): string {
  const lines: string[] = ['Сравнил выбранные товары.'];

  if (presentation.keyDifferences.length) {
    lines.push(
      '',
      'Ключевые различия:',
      ...presentation.keyDifferences.map((difference) => `— ${difference}`),
    );
  }

  lines.push('', `Что выбрать: ${presentation.recommendation}`);

  if (presentation.note) {
    lines.push('', presentation.note);
  }

  return lines.join('\n');
}

// ===== END CHANGE: DETERMINISTIC COMPARISON PRESENTATION =====
