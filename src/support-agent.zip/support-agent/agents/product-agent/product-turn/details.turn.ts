import type { ProductAgentStateUpdate } from '../product-agent.state';
import {
  finishDeterministicTurn,
  type ConsultationRuntime,
} from './consultation-runtime';
import type { ProductTurnContext } from './product-turn.context';

export function handleDetailsTurn(
  turn: ProductTurnContext,
  runtime: ConsultationRuntime,
): ProductAgentStateUpdate {
  const { state } = turn;

  const { core, products } = runtime;

  const reference = state.turn.products[0];

  core.getProductDetails({
    needId: reference.needId,

    productIds: [reference.productId],

    attributeIds: state.turn.attributeIds.length
      ? state.turn.attributeIds
      : null,

    presentation: 'details',
  });

  const message = `Подробная информация: ${products[0].title}.`;

  return finishDeterministicTurn(turn, runtime, message);
}
