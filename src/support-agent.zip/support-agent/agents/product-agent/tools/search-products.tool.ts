// import { ToolMessage } from '@langchain/core/messages';
// import { Command } from '@langchain/langgraph';
// import { tool, type ToolRuntime } from 'langchain';

// import { ProductAgentService } from '../product-agent.service';
// import { ProductAgentState } from '../product-agent.state';
// import { ProductNeedSchema } from '../schemas/product-need.schema';

// export function createSearchProductsTool(
//   productAgentService: ProductAgentService,
// ) {
//   return tool(
//     async (
//       productNeed,
//       runtime: ToolRuntime<typeof ProductAgentState.State>,
//     ) => {
//       const result = await productAgentService.searchProducts(productNeed);

//       const content = [
//         `Найдено товаров: ${result.products.length}.`,
//         ...result.products.map(
//           (product) => `- ${product.title}, цена: ${product.price}`,
//         ),
//       ].join('\n');

//       return new Command({
//         update: {
//           searchResults: [result],

//           messages: [
//             new ToolMessage({
//               content,
//               tool_call_id: runtime.toolCall?.id ?? '',
//             }),
//           ],
//         },
//       });
//     },
//     {
//       name: 'search_products',

//       description:
//         'Ищет товары по ProductNeed. Вызывай для каждой независимой товарной потребности, как только понятен тип или класс нужного товара.',

//       schema: ProductNeedSchema,
//     },
//   );
// }

import { HumanMessage, ToolMessage } from '@langchain/core/messages';
import { Command } from '@langchain/langgraph';
import { tool, type ToolRuntime } from 'langchain';
import { z } from 'zod';
import { ProductAgentService } from '../product-agent.service';
import { ProductAgentState } from '../product-agent.state';
import { ProductNeedSchema } from '../schemas/product-need.schema';
import { ConsultationAgent } from '../subagents/consultation-agent/consultation.agent';

import {
  ConsultationAgentInputSchema,
  ConsultationAgentResultSchema,
} from '../subagents/consultation-agent/schemas/consultation-agent.schema';

const SearchProductsInputSchema = z.object({
  needs: z
    .array(ProductNeedSchema)
    .min(1)
    .max(5)
    .describe(
      'Все независимые товарные потребности текущего пользовательского запроса.',
    ),
});

export function createSearchProductsTool(
  productAgentService: ProductAgentService,
  consultationAgent: ConsultationAgent,
) {
  return tool(
    async (input, runtime: ToolRuntime<typeof ProductAgentState.State>) => {
      const searchResults = await Promise.all(
        input.needs.map((productNeed) =>
          productAgentService.searchProducts(productNeed),
        ),
      );
      const consultationInput = ConsultationAgentInputSchema.parse({
        searches: searchResults.map((result) => ({
          productNeed: result.productNeed,

          products: result.products.slice(0, 5).map((product) => ({
            title: product.title,
            price: product.price,
          })),
        })),
      });

      const consultationResult = await consultationAgent.invoke(
        {
          messages: [
            new HumanMessage(
              JSON.stringify({
                searches: consultationInput.searches,
              }),
            ),
          ],
        },
        runtime.config,
      );

      const finalConsultationMessage = consultationResult.messages.at(-1);

      if (!ToolMessage.isInstance(finalConsultationMessage)) {
        throw new Error(
          'SearchProductsTool: ConsultationAgent не завершился через complete_consultation_step',
        );
      }

      const consultation = ConsultationAgentResultSchema.parse(
        finalConsultationMessage.artifact,
      );

      return new Command({
        update: {
          searchResults,

          consultation,

          messages: [
            new ToolMessage({
              name: 'search_products',

              content: consultation.message,

              tool_call_id: runtime.toolCall?.id ?? '',
            }),
          ],
        },
      });
    },
    {
      name: 'search_products',

      description:
        'Выполняет товарный поиск. Передавай все независимые ProductNeed текущего запроса одним вызовом в needs.',

      schema: SearchProductsInputSchema,
      returnDirect: true,
    },
  );
}
