import { tool } from '@langchain/core/tools';
import { Command } from '@langchain/langgraph';
import { z } from 'zod';

export const transferToCustomerHelpTool = tool(
  async () => {
    return new Command({
      goto: 'customerHelp',

      graph: Command.PARENT,

      update: {
        // CustomerHelp становится владельцем диалога.
        activeAgent: 'customerHelp',
      },
    });
  },
  {
    name: 'transfer_to_customer_help',

    description:
      'Передай управление Customer Help, если пользователь спрашивает о доставке, оплате, возврате, обмене, скидках, программе лояльности или других правилах магазина.',

    schema: z.object({}),
  },
);
